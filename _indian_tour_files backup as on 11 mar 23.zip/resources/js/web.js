global.$ = global.jQuery = require('jquery');
require('../../public/admin/assets/js/jquery-3.2.1.min.js')
require('../../public/admin/assets/js/bootstrap.min.js');
require('../../public/admin/assets/js/canvasjs.min.js');
require('../../public/admin/assets/js/counterup.min.js');
require('../../public/admin/assets/js/jquery.slicknav.js');
require('../../public/admin/assets/js/dashboard-custom.js');