@extends('layouts.front')

@section('content')
<main id="content" class="site-main">
<!-- Inner Banner html start-->
<section class="inner-banner-wrap">
        <div class="inner-baner-container" style="background-image: url(assets/images/inner-banner.jpg);">
            <div class="container">
                <div class="inner-banner-content">
                <h1 class="inner-title">Privacy Policy</h1>
                </div>
            </div>
        </div>
        <div class="inner-shape"></div>
    </section>
    <!-- Inner Banner html end-->
    <!-- contact form html start -->
    <div class="contact-page-section">
        <div class="contact-form-inner">
            <div class="container">
                <div class="row">
                <div class="col-md-12">
                    <div class="contact-from-wrap">
<p>Indian-Tours governs the privacy of its users and whoever comes on website www.indian-tours.in. The privacy policy describes our policy in details and how this website protects and store user information. We collect user data after the confirmation given by the user and they state that they have read our privacy policy. The user data are therefore used to give a customer a user-friendly experience.</p>
<h4>Overview</h4>
<p>This website abides by all the Indian Laws and is judiciary system for user privacy. The proactive approach is taken by the owners of this company to protect the rights and information of the user. The necessary measures are taken to protect the loss, misuse and alteration of data. Indian-Tours protects the customer information efficiently but the transmission of information is not 100% secure on the internet.</p>
<h3>What is Indian-Tours?</h3>
<p>indian-tours.in is a one-stop destination for travelers looking to explore the beautiful and diverse North to South India. Triund Trek Dharamshala, Camping in Kasol, and Delhi Safari are some of our most popular tours. We are specialized in creating tailor-made itineraries that allow travelers to see as much as possible while keeping their budgets in mind.</p>
<p>We believe that traveling should be an enjoyable experience and we strive to provide the best possible service to our customers. Our team of experts have been traveling extensively throughout North to South India for years, so you can be sure you're in good hands. .</p>

<h4>Our Commitment to Privacy</h4>

<p>Indian-Tours is committed to protecting the privacy of its website visitors. This policy sets out our practices concerning the collection, use, and disclosure of personal information collected from our website. </p>

<p>We collect personal information when you register for our services, subscribe to our email newsletters, or contact us via the contact form. We also gather information about your visit to our website, such as which pages you view and how long you spend on each page. </p>

<p>We use the collected personal information only for the purposes described in this policy or accordance with applicable law. We do not sell or rent your personal information to third parties. </p>

<p>We will not collect any personal information if you do not want us to. You can refuse to supply certain sensitive data by selecting that option when you provide it to us. However, if you choose not to supply certain data, we may not be able to provide you with some of the services that we offer. </p>

<p>We will delete your personal information upon request if you no longer wish us to have it or if we no longer need it for the purposes for which it was collected. </p>

<p>If at any time you have questions about our privacy policy or wish to make changes to your personal information, please contact us at support@indian-tours.in</p>
<h4>How we collect and use your data</h4>

<p>Indian-Tours collects and uses your data through our Privacy Policy. Our policy is to collect only the information that is necessary for us to provide you with the products and services you have requested. We will never sell or rent your personal information to third parties. We will always keep your information confidential. If you have any questions about our privacy policy, please feel free to contact us at support@indian-tours.in</p>

<h4>Your rights when it comes to your data</h4>

<p>When you book an Indian tour, you're giving the company permission to collect and use your data. The company will need to get your consent before using any of the following: your name, email address, phone number, postal code, and date of birth. <//p>

</p>The company is also required to keep track of updates to its privacy policy so that you are always aware of what information the company collects and how it's used. <//p>

<h4>Indian-Tours.in cookies</h4>

</p>Indian-Tours.in is committed to protecting the privacy of its users. This policy describes how Indian-Tours.in collects and uses user data. <//p>

<h4>Information Collection</h4>

</p>Indian-Tours.in does not collect any personally identifiable information from its users. Instead, Indian-Tours.in collects anonymous demographic information about its users, such as their age and gender, which is used for marketing purposes only. <//p>

<h4>Use of Data</h4>

</p>Indian-Tours.in does not sell, rent, or lease its user data to third parties. Indian-Tours.in uses the collected user data to improve the content and functionality of the website, to better serve its users, and to track the activities of individual users on the website so that they can be better informed about what interests them. <//p>

<h4>Indian-Tours.in security</h4>

</p>Indian-Tours.in takes privacy seriously! We operate a secure website to protect your personal information. Our website uses Secure Socket Layer (SSL) technology to encrypt all of your data as it travels between your computer and our servers. Additionally, we also use a variety of security measures, such as firewalls and passwords, to protect your information from unauthorized access. Indian-Tours.in will never sell or share your personal information with any third party without your consent. <//p>

<h4>How to contact Indian-Tours.in</h4>

</p>If you have any questions about our privacy policy or would like more information about the personal information we collect, please contact us at support@indian-tours.in<//p>

<h4>How do we protect your personal information? </h4>

</p>We take appropriate security measures to protect your personal information from unauthorized access, use, or disclosure. We regularly review our security procedures to ensure that they are adequate to protect the confidentiality, integrity and security of your personal information. <//p>
                    </div>
                </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
        <!-- <div class="map-section">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d317838.95217734354!2d-0.27362819527326965!3d51.51107287614788!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x487604c7c7eb9be3%3A0x3918653583725b56!2sRiverside%20Building%2C%20County%20Hall%2C%20Westminster%20Bridge%20Rd%2C%20London%20SE1%207JA%2C%20UK!5e0!3m2!1sen!2snp!4v1632135241093!5m2!1sen!2snp" height="400" allowfullscreen="" loading="lazy"></iframe>
        </div>
    </div> -->
    <!-- contact form html end -->
</main>
@endsection
@section('scripts')
    <script type="text/javascript">
    $('#reload').click(function () {
    $.ajax({
    type: 'GET',
    url: 'reload-captcha',
    success: function (data) { console.log(data);
    $(".captcha span").html(data.captcha);
    }
    });
    });
    </script>
@endsection