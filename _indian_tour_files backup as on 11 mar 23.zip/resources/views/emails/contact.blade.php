Hello <strong>Indian Tours Team,</strong>
<p>Please find below Contact Enquiry:</p>
<p>Name: {{$body->name}}</p>
<p>Email: {{$body->email}}</p>
<p>Message: {{$body->message}}</p>
<p></p><p></p><p></p>
<p>Thank you,</p>
{{$name}}
