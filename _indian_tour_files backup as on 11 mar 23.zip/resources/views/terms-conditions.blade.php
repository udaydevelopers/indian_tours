@extends('layouts.front')

@section('content')
<main id="content" class="site-main">
<!-- Inner Banner html start-->
<section class="inner-banner-wrap">
        <div class="inner-baner-container" style="background-image: url(assets/images/inner-banner.jpg);">
            <div class="container">
                <div class="inner-banner-content">
                <h1 class="inner-title">Terms and Conditions</h1>
                </div>
            </div>
        </div>
        <div class="inner-shape"></div>
    </section>
    <!-- Inner Banner html end-->
    <!-- contact form html start -->
    <div class="contact-page-section">
        <div class="contact-form-inner">
            <div class="container">
                <div class="row">
                <div class="col-md-12">
                    <div class="contact-from-wrap">
<h4>Introduction</h4>
<p>As a business owner, you know that it’s important to be transparent with your customers. That means being clear about what services or products you offer, and the terms and conditions governing those services or products. When it comes to booking travel services, there are a lot of online booking engines out there that allow you to create listings quickly and easily. However, it’s always a good idea to review your terms and conditions before you list your trip. This will help protect yourself (and your customers) from any unexpected surprises down the road. </p>
<h4>Terms and Conditions</h4>

<p>The following terms and conditions apply to all tours, services and products offered by Indian-Tours. By booking a tour or making a purchase through Indian-Tours, you are agreeing to be bound by these terms and conditions. If you do not agree to these terms, please do not book a tour through Indian-Tours or make any purchases. </p>

<p>Indian-Tours reserves the right to change or modify these terms at any time without prior notice. All changes will be posted on this page and/or included in our emails alerting customers of the changes. It is your responsibility to check this page regularly for any updates. Your continued use of Indian-Tours after we have posted changes means that you agree to be bound by the revised terms. </p>

<p>If you have questions about these terms, please contact us at [email protected]. We hope that you enjoy using Indian-Tours! </p>

<h4>How Indian-Tours works</h4>

<p>Indian-Tours is an online travel agency that specializes in offering Indian tours. The company was founded by Shekhar Virdi who wanted to create an easier way for people to find and book authentic Indian tours. </p>

<p>The website offers a variety of different types of tours, from cultural trips to adventure outings. Each tour is carefully chosen to give visitors a unique and memorable experience. </p>

<p>Indian-Tours offers a variety of payment options, including credit cards, PayPal, and bank transfers. The site also allows visitors to book individual tours or join one of the company's special interest groups. </p>

<p>All of the information on Indian-Tours is provided in English, so anyone with a curiosity about India can explore the site's offerings. </p>

<h4>Fees</h4>

<p>Indian-Tours offers visitors the opportunity to experience a genuine and traditional Indian life by booking tours from Delhi, Agra, Jaipur and Mumbai. The company advertises its tours as "the best way to see India" because of the high quality of the services it provides. </p>

<p>The company also charges additional fees depending on the type of tour booked. For example, one fee is charged if visitors want to visit certain sites outside of scheduled destinations while another fee is charged if visitors want to stay overnight in specific locations. In addition, some guests may be required to pay an airport surcharge if they book their tour through an online ticketing platform such as Expedia or Travelocity rather than through Indian-Tours directly. </p>

<h4>Prohibited Activities</h4>

<p>The following are prohibited activities while participating in our tours: </p>
<ui>
<li> Smoking</li>
<li> Drinking alcohol</li>
<li> Eating or drinking outside the designated areas of the tour</li>
<li> Scaring or harassing animals</li>
<li> Making noise that is disruptive, offensive, or dangerous to others</li>
</ui><br>
<h4>Information From Children</h4>
<p>We do not knowingly solicit, collect or retain information from any individuals under the age of 13. </p>

<h4>What happens if I miss my flight? </h4>

<p>If you miss your flight, Indian-Tours will do its best to reschedule the tour for you. However, some restrictions may apply and it is at the discretion of the company whether or not they are able to do so. In the event that a new tour is required as a result of your missed flight, Indian-Tours will endeavour to make arrangements with the same or similar company or other tour operator in order to minimize any inconvenience to you. </p>

<h4>Customer Service</h4>

<p>If you have any queries or concerns about your booking, don't hesitate to contact us. Our team is available 24/7 to help resolve any issues you may have. </p>

<p>We recommend that you send us an email using the Contact Form on our website if you need assistance. Unfortunately we are not able to offer telephone support, as this would require our team to be available during office hours in India. </p>

<p>If you have still not been able to resolve your issue after following all of the steps outlined above, then please reach out to us for assistance via our Live Chat feature on our website. We'll be happy to provide a solution or help with further information. </p>

<p>Our customer service team is always willing and ready to help! </p>

<h4>Cancellation Policy</h4>

<p>If you cancel within 7 days of your tour start date, we will refund all payments made. If you cancel after 7 days but before the end of your tour, we will refund 80% of the payment. If you cancel after the end of your tour, no refunds are available. </p>

<h4>General Conditions of Use</h4>

<p>The blog post "Terms And Conditions" provides general information about the terms of use for Indian-Tours, a travel company specializing in Indian tourism. In addition to the terms of use, the post also describes the company's refund policy, customer service procedures, and how to make a booking. </p>

<p>Indian-Tours reserves the right to change or modify these Terms of Use at any time without notice. Changes will be effective when posted on this website and accepted by you. Your continued use of Indian-Tours following such changes constitutes your acceptance of such changes. </p>

<p>Please note that all prices are subject to change at any time without notice. The prices shown on our website are only estimates and should not be relied upon as gospel. Prices quoted may include taxes and other charges which are not included in advertised prices and are subject to change without notice. </p>

<p>If you have any questions about these Terms of Use or booking with Indian-Tours please contact us at support@indian-tours.in</p>

<h4>What is the refund policy for Indian-Tours? </h4>

<p>Indian-Tours offers a 100% refund policy for all tickets purchased through their website. All refunds will be processed within 7-10 business days. If you have any questions or concerns about your refund, please contact Indian-Tours at support-at-indian-tours.in </p>

<h4>Are there any discounts available for Indian-Tours? </h4>

<p>There are a few discounts available for Indian-Tours. The first discount is for students who are registered with their school or university. The second discount is for seniors (60 years of age or older). Finally, the last and most substantial discount is for people who are travelling with a group of four or more. </p>

                    </div>
                </div>
                        
                    </div>
                </div>
                </div>
            </div>
        </div>
        <!-- <div class="map-section">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d317838.95217734354!2d-0.27362819527326965!3d51.51107287614788!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x487604c7c7eb9be3%3A0x3918653583725b56!2sRiverside%20Building%2C%20County%20Hall%2C%20Westminster%20Bridge%20Rd%2C%20London%20SE1%207JA%2C%20UK!5e0!3m2!1sen!2snp!4v1632135241093!5m2!1sen!2snp" height="400" allowfullscreen="" loading="lazy"></iframe>
        </div>
    </div> -->
    <!-- contact form html end -->
</main>
@endsection
@section('scripts')
    <script type="text/javascript">
    $('#reload').click(function () {
    $.ajax({
    type: 'GET',
    url: 'reload-captcha',
    success: function (data) { console.log(data);
    $(".captcha span").html(data.captcha);
    }
    });
    });
    </script>
@endsection