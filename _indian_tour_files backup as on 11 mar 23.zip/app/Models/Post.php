<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;

class Post extends Model
{
    use HasFactory;

    public function tags()
    {
    	return $this->belongsToMany('App\Models\Tag','post_tags')->withTimestamps();
    }

    public function getRouteKeyName()
    {
    	return 'slug';
    }

    public function getCreatedAtAttribute($value)
    {
        return Carbon::parse($value)->diffForHumans();
    }

    public function likes()
    {
        return $this->hasMany('App\Model\user\like');
    }

    public function getSlugAttribute($value)
    {
        return route('post',$value);
    }

    public function scopeLatest($query)
    {
        return $query->orderBy('id', 'DESC');
    }

}
